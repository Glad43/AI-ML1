Команды для запуска:

1.git clone https://github.com/Artem-megamozg/AI-Multi.git

2.python setup.py

3. .venv/bin/activate
   
4.python setup2.py

5.python gpu.py команда для нагрузки ГПУ

6.python cpu.py команда для нагрузки ЦПУ

7.gpustat команда для проверки нагрузки ГПУ

8.htop команда для проверки нагрузки ЦП 

Примечание, отправленный архив, является датасетом для обучения нейросети для нагрузки ЦПУ, его нужно загрузить на сервер и разархивировать 

